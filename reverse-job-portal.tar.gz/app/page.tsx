export default function Home() {
  return (
    <main className="max-w-4xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-4">Umgekehrtes Job-Portal</h1>
      <p className="text-lg mb-8">Firmen suchen hier aktiv nach passenden Kandidaten.</p>
      
      <div className="grid gap-4">
        <a href="/candidates" className="bg-blue-600 text-white px-6 py-3 rounded-lg inline-block text-center">
          Kandidaten suchen (für Firmen)
        </a>
        <a href="/profile" className="bg-gray-200 px-6 py-3 rounded-lg inline-block text-center">
          Mein Profil (für Kandidaten)
        </a>
      </div>
    </main>
  )
}
