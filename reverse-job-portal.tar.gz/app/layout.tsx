import './globals.css'

export const metadata = {
  title: 'Reverse Job Portal',
  description: 'Firmen suchen Kandidaten',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body className="bg-gray-50">{children}</body>
    </html>
  )
}
