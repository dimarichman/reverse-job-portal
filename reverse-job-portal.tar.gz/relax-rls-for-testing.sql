-- Temporär für Tests: Öffentliche Leserechte auf Kandidaten
-- (Später wieder entfernen und durch richtige Policies ersetzen)

drop policy if exists "Companies can view all candidates" on public.candidates;

create policy "Public can view candidates"
  on public.candidates for select
  using (true);

-- Optional: Inserts erlauben (nur für Tests!)
create policy "Allow public inserts for testing"
  on public.candidates for insert
  with check (true);
