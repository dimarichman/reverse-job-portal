# Umgekehrtes Job-Portal – MVP

Firmen suchen aktiv nach Kandidaten (nicht umgekehrt).

## Tech-Stack (kostenlos)
- **Supabase**: Datenbank, Auth, Storage
- **Next.js** + React + Tailwind: Frontend
- **Vercel**: Hosting

## Datenmodell
Siehe `schema.sql` – einfach in Supabase SQL Editor einfügen und ausführen.

### Tabellen
- `candidates`: Kandidatenprofile (Skills, Bio, Standort, etc.)
- `companies`: Firmenprofile
- `contact_requests`: Kontaktanfragen

## Nächste Schritte
1. Supabase-Projekt anlegen (supabase.com – kostenlos)
2. Schema ausführen
3. Ich programmiere die Next.js App
4. Auf Vercel deployen (Anleitung folgt)

Alles wird so gebaut, dass du später nur noch Daten in Supabase änderst oder mir sagst, was angepasst werden soll.
