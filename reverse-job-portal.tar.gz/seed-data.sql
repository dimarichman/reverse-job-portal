-- Test-Daten einfügen (im Supabase SQL Editor ausführen)
-- Danach sollten sie in der Suche erscheinen

insert into public.candidates (full_name, title, bio, skills, location, experience_years)
values
  ('Max Mustermann', 'Senior Frontend Entwickler', 'Leidenschaftlicher React-Entwickler mit Fokus auf moderne Web-Apps.', ARRAY['React', 'TypeScript', 'Next.js', 'Tailwind'], 'Hamburg', 6),
  ('Anna Schmidt', 'UX/UI Designerin', 'Gestalte intuitive und schöne Benutzeroberflächen.', ARRAY['Figma', 'User Research', 'Prototyping', 'Design Systems'], 'Berlin', 4),
  ('Tom Weber', 'Full-Stack Entwickler', 'Backend und Frontend – Node.js und React.', ARRAY['Node.js', 'PostgreSQL', 'React', 'Python'], 'München', 8),
  ('Lisa Müller', 'Product Manager', 'Bringe Produkte von der Idee bis zum Launch.', ARRAY['Agile', 'Roadmapping', 'Stakeholder Management'], 'Köln', 5);
