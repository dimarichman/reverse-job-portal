-- Supabase Schema für umgekehrtes Job-Portal (MVP)
-- Firmen suchen Kandidaten

-- Extensions
create extension if not exists "uuid-ossp";

-- Profiles table (Kandidaten)
create table public.candidates (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade unique,
  full_name text not null,
  title text, -- z.B. "Senior Frontend Entwickler"
  bio text,
  skills text[], -- Array von Skills
  location text,
  experience_years integer,
  availability text, -- "sofort", "1 Monat", etc.
  salary_expectation text,
  cv_url text, -- Link zu Supabase Storage
  photo_url text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Companies (Firmen)
create table public.companies (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references auth.users(id) on delete cascade unique,
  company_name text not null,
  website text,
  description text,
  location text,
  created_at timestamptz default now()
);

-- Contact requests (Kontaktanfragen von Firmen an Kandidaten)
create table public.contact_requests (
  id uuid primary key default uuid_generate_v4(),
  company_id uuid references public.companies(id) on delete cascade,
  candidate_id uuid references public.candidates(id) on delete cascade,
  message text not null,
  status text default 'pending', -- pending, accepted, rejected
  created_at timestamptz default now()
);

-- Row Level Security
alter table public.candidates enable row level security;
alter table public.companies enable row level security;
alter table public.contact_requests enable row level security;

-- Policies (einfach für MVP)
-- Kandidaten können ihr eigenes Profil sehen/bearbeiten
create policy "Candidates can manage own profile"
  on public.candidates for all
  using (auth.uid() = user_id);

-- Firmen können alle Kandidaten sehen (Suche)
create policy "Companies can view all candidates"
  on public.candidates for select
  using (exists (select 1 from public.companies where user_id = auth.uid()));

-- Firmen können ihr eigenes Profil verwalten
create policy "Companies manage own"
  on public.companies for all
  using (auth.uid() = user_id);

-- Kontaktanfragen: Firmen können erstellen, beide können sehen
create policy "Companies can create contacts"
  on public.contact_requests for insert
  with check (exists (select 1 from public.companies where id = company_id and user_id = auth.uid()));

create policy "View own contacts"
  on public.contact_requests for select
  using (
    exists (select 1 from public.companies where id = company_id and user_id = auth.uid())
    or exists (select 1 from public.candidates where id = candidate_id and user_id = auth.uid())
  );

-- Updated at trigger
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger update_candidates_updated_at
  before update on public.candidates
  for each row execute function update_updated_at();
